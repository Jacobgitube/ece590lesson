#include <iostream>
#include <vector>
#include <algorithm>

void sortIntnum(std::vector<int>& num) {
    std::sort(num.rbegin(), num.rend());
}

int main() {
    std::vector<int> sampleContainer = {1,3,5,7,2,8};
    
    // Sorting the sample container in descending order
    sortIntnum(sampleContainer);
    
    // Printing the sorted elements
    for(int num : sampleContainer) {
        std::cout << num << " ";
    }
    std::cout << std::endl;
    return 0;
}
