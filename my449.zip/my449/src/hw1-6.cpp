#include <iostream>//imports the header file for input/output standard functions
#include <algorithm>//includes the header file for various algorithms.
#include <list>//includes the header file for lists. Lists are a data structure that stores elements as "nodes," where each node contains a pointer to the next node.
#include <vector>//includes the header file for vectors. Vectors are a dynamic array that allows fast random access to elements.
#include <chrono>// includes the header file for time-related operations.

int main()
{
    std::vector<int> integers_vector;//Declares an integer vector 'integers_vector'.
    std::list<int> integers_list;// Declares an integer list 'integers_list'.
//Declares and initializes a 'size_t' variable 'max_size' with a value of 100,000,000.
    size_t max_size = 1000000;
// Loops to add integers from 0 to 99,999,999 to the integer vector and list.
    std::cout << "inserting values into vector and list..." << std::endl;
    for(size_t i = 0; i < max_size; i++)
    {
        integers_vector.push_back(i);
        integers_list.push_back(i);
    }
// Generates a random number between 1 and 'max_size' for later searching in the vector and the list.
    size_t random_number = rand() % max_size + 1;
// Prints the random number that will be searched for in the vector and the list.
    std::cout << "random number to find in vector and list is: " << random_number << std::endl;//Prints the random number that will be searched for in the vector and the list.
//Searches for the random number in the integer vector.  
    std::cout << "searching in vector..." << std::endl;
    auto start_vector = std::chrono::high_resolution_clock::now();
    std::find(integers_vector.begin(),integers_vector.end(),random_number);// Searches for the random number in the integer vector.
    auto end_vector = std::chrono::high_resolution_clock::now();
///Searches for the random number in the list
    std::cout << "searching in list..." << std::endl;
    auto start_list = std::chrono::high_resolution_clock::now();
    std::find(integers_list.begin(),integers_list.end(),random_number);// Searches for the random number in the integer list.
    auto end_list = std::chrono::high_resolution_clock::now();
//Calculates the time taken to search for the random number in the integer vector.
//Calculates the time taken to search for the random number in the integer list.
    std::chrono::duration<double, std::milli> vector_time = end_vector - start_vector;
    std::chrono::duration<double, std::milli> list_time = end_list - start_list;
//Prints the time taken to search for the random number in the vector and list
    std::cout << "Time took searching " << random_number << " in vector: " << vector_time.count() << "ms" << std::endl;
    std::cout << "Time took searching " << random_number << " in list: " << list_time.count() << "ms" << std::endl;
    
    return 0;
}