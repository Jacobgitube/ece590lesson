#include <string>
#include <iostream>
const std::string hello = "Hello";
const std::string message = hello + ", world" + "!";
void printMessage(const std::string& message){
     std::cout << message << std::endl;
}
int main() {
    printMessage(message);
    return 0;
}