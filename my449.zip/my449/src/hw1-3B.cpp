#include <vector>
#include <algorithm>
#include<iostream>
int main() {
    std::vector<int> u(10, 100);
    std::vector<int> v;
    v.resize(u.size());  
    std::copy(u.begin(), u.end(), v.begin());
    
    for (int i = 0; i < v.size(); i++) {
        std::cout << v[i] << " ";
    }
    
    return 0;
}
