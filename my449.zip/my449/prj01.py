from ast import Constant
import numpy as np
import easynn as nn
from easynn_golden import Add, Mul, Neg
# Create a numpy array of 10 rows and 5 columns.
sample_array= np.array([[1, 2, 3, 4, 5],
                        [5, 6, 7, 8, 9],
                        [1, 3, 5, 7, 9],
                        [2, 4, 6, 8, 2],
                        [1, 3, 5, 7, 9],
                        [1, 2, 3, 4, 5],
                        [2, 3, 4, 5, 6],
                        [3, 4, 5, 6, 7],
                        [5, 6, 7, 8, 9],
                        [2, 3, 5, 6, 7]])
#Set the element at row i and column j to be i+j.
def Q1():
    new_array = np.random.rand(10,5)
    for i in range(10):  # 10 rows
        for j in range(5):  # 5 columns
            new_array[i, j] = i + j
    return new_array
#Add two numpy arrays together.
def Q2(a, b): 
    return (a+b)
array1=([[1,2,3],[4,5,6],[1,1,1],[2,2,2]])
array2=([[1,2,3],[1,2,3],[1,2,3],[4,5,6]])
tsum=Q2(array1,array2)



# Multiply two 2D numpy arrays using matrix multiplication.
def Q3(a, b):
    return np.dot(a,b)
array1=([[1,2,3],[4,5,6]])
array2=([[1,2],[1,2],[1,2]])
Tmul=Q3(array1,array2)

# For each row of a 2D numpy array, find the column index
# with the maximum element. Return all these column indices.
def Q4(a):
   max_indices = np.argmax(a, axis=1)
   return max_indices
result1=Q4(array1)
# Solve Ax = b.
def Q5(A, b):
      x = np.linalg.solve(A, b)
      return x

# Return an EasyNN expression for a+b.
def Q6():
    a = nn.Input("a")
    b = nn.Input("b")
    add_expr = Q2(a, b)

    return add_expr

# Return an EasyNN expression for a+b*c.
def Q7():
    a = nn.Input("a")
    b = nn.Input("b")
    c=nn.Input("c")
    mul_expr = Q3(b,c)
    add_expr = Q2(a,mul_expr)
    return add_expr

# Given A and b, return an EasyNN expression for Ax+b.
def Q8(A, b):
    x = nn.Input("x")
    A=nn.Const(A)
    d=np.dot(A,x)
    return d+b
    
# Given n, return an EasyNN expression for x**n.
def Q9(n):
    x = nn.Input("x")
    result = x
    for _ in range(n - 1):
        result = result * x
    return result

# Return an EasyNN expression to compute
# the element-wise absolute value |x|.
def Q10():
    x=nn.Input("x")
    abs=nn.ReLU()
    e=abs(x)
    return e*2-x
     
   
