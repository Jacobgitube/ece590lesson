#include <iostream>
#include <vector>

int main() {
    std::vector<int> temp = { 1, 2, 3, 4, 5 };
    std::vector<int> v;
    v.resize(temp.size()); 
    std::copy(temp.begin(), temp.end(), v.begin());

    // 使用迭代器遍历向量并打印其中的每个元素
    for (auto it = v.begin(); it != v.end(); ++it) {
        std::cout << *it << " ";
    }

    std::cout << std::endl; // 打印换行

    return 0;
}
